<!DOCTYPE html>
<html>
<head>
    <!-- ... -->
    @routes
    @viteReactRefresh
    @vite(['resources/css/app.css', 'resources/js/app.jsx'])
</head>
<body>
    @inertia
</body>
</html>